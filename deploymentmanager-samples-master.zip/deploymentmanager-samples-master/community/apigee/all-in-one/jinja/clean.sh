gcloud deployment-manager deployments delete $1
