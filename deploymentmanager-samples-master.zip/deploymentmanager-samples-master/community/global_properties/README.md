The purpose of this example is to show how to add an additional YAML file as a
set of 'global properties', that is properties that can be read everywhere
without needing to be passed to each resource.

