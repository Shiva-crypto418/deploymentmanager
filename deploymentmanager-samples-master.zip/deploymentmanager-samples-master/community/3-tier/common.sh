#!/bin/bash 

. ./vars.txt

echo_mesg() {
   echo "  ----- $1 ----  "
}
