# Contributing to Deployment Manager Community Examples

Contributors inside and outside Google can submit samples in "Community" folder. Github issues for community samples will be assigned back to the original author after triaged by Deployment Manager team. These samples won't be actively tested by Deployment Manager team.

## License

Apache 2.0 - See [LICENSE](LICENSE) for more information.
