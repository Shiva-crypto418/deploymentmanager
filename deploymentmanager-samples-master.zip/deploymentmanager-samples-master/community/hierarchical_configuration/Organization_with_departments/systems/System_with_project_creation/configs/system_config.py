config = {
    'Systen description': 'Sample system to demonstrate project creation',
}
