config = {
    'CONTEXT': 'We are in Master context',
    'System_Lead': 'Johns Smiths',
}
