config = {
    'Department_level_configs': {
        'Department_Name': 'Finance Department',
        'Department_Short_Name': 'FIN'
    }
}
