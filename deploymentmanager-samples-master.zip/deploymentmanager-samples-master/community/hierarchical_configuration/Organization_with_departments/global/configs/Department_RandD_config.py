config = {
    'Department_level_configs': {
        'Department_Name': 'Data Analisys Department',
        'Department_Short_Name': 'DATA'
    }
}
