config = {
    'Org_level_configs': {
        'Org_Name': 'Sample Inc.',
        'Org_Short_Name': 'sampl',
        'HQ_Address': {
            'City': 'London',
            'Country': 'UK'
        }
    }
}
