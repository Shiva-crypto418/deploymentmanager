config = {
    'CONTEXT': 'We are in TestFrontend context',
    'IntanceType': 'medium',
    'InstanceMin': '2',
    'InstanceMax': '6',
    'ServiceVersion': 'v3.65'
}
