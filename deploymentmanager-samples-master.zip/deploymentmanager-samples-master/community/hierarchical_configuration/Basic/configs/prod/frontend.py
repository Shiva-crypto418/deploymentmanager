config = {
    'CONTEXT': 'We are in PROD-Frontend context',
    'IntanceType': 'micro',
    'InstanceMin': '3',
    'InstanceMax': '10',
    'ServiceVersion': 'v3.45'
}
