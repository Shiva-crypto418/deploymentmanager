config = {'CONTEXT': 'We are in PROD context'}
