config = {
    'CONTEXT': 'We are in Dev Frontend context',
    'ServiceVersion': 'v4.25'
}
