config = {
    'CONTEXT': 'We are in FrontendModule context',
    'IntanceType': 'f1-micro',
    'ServiceName': 'FrontendApache',
    'BackupBucket': 'gs://backupbucket1',
    'Instance': {
        'OSFamily': 'debian-cloud',
        'OSVersion': 'debian-9',
        'InstanceType': 'f1-micro'
    }
}
