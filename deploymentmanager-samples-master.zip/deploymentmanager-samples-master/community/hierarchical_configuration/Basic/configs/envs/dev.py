config = {
    'CONTEXT': 'We are in DEV context',
    'Log_bucket': 'gc://bucketname_great',
    'versionNR': 'v12.236',
    'zone': 'europe-west1-d',
}
