config = {
    'CONTEXT': 'We are in TEST context',
    'Log_bucket': 'gc://bucketname_great5',
    'versionNR': 'v14.236',
    'zone': 'europe-west1-d',
}
