config = {
    'CONTEXT': 'We are in PROD context',
    'Log_bucket': 'gc://bucketname_great2',
    'versionNR': 'v12.333',
    'zone': 'europe-west1-c',
}
