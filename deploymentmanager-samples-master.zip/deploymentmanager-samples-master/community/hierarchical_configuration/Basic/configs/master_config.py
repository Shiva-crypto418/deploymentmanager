config = {
    'CONTEXT': 'We are in Master context',
    'Org_Name': 'Sample Inc',
    'Department_name': 'Department of silly walks',
    'HQ_Address': {
        'City': 'London',
        'Country': 'UK'
    }
}
