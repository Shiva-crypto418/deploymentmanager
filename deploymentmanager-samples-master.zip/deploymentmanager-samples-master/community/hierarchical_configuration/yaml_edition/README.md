# Deployment Manager at Scale

## YAML edition

This version of the configuration merger supports both YAML and Python structured configuration properties.

### YAML

The context of the YAML files are loaded directly into the configuration dictionary.

### Python

The python file has to store the configuration under a dictionary called 'config'.