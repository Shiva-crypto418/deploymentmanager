# Deployment Manager Resource Snippets

This directory contains Deployment Manager templates for demonstrating and testing the configuration of all GCP resources. The Deployment Manager team will test and maintain these resource snippet samples.

## License

Apache 2.0 - See [LICENSE](LICENSE) for more information.
