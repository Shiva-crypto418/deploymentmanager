# Deployment Manager Solutions

This directory contains Deployment Manager solutions that are created and managed by Google. The Deployment Manager team will test and maintain these samples.

## License

Apache 2.0 - See [LICENSE](LICENSE) for more information.
