# Create Container Deployment

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/create-container-deployment)
configuration example that creates a VM using containers. To use it, replace
ZONE_TO_RUN with a specific zone in container_vm.yaml file. This example can use
either Jinja or Python templates.
