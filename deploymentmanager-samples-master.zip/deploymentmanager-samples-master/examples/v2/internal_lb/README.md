# Internal load balancers

These templates follow the internal load balancing
[tutorial](https://cloud.google.com/compute/docs/load-balancing/internal/). You
can create a deployment and SSH onto the test instance to run curl against your
load balancer (find the IP address in Cloud Console).
