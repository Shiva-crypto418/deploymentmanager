# IAM Example

This example creates a service account, a VM, and a Pub/Sub topic. The VM runs
as the service account, and the service account has subscriber access to the
Pub/Sub topic, thereby giving services and applications running on the VM access
to the Pub/Sub topic.
