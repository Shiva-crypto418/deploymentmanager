# Create a configuration using multiple templates

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/using-multiple-templates)
configuration file which creates two virtual machine instances using multiple
Jinja or Python templates. To use it, replace [MY_PROJECT] with your project ID.
