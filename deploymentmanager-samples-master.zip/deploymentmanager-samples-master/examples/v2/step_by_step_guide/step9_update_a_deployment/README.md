# Update deployment

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/updating-a-deployment)
deployment example that updates the deployment with modified startup-script in
vm-template.py file from previous step.
