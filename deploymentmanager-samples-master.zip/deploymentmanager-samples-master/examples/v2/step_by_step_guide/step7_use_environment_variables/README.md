# Create a configuration using environment variables

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/using-template-and-environment-variables)
configuration file which creates two virtual machine instances using multiple
Jinja or Python templates with environment variables.
