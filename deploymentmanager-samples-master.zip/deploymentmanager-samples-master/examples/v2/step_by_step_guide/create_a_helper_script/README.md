This directory contains files that allow users to create helper scripts in the interactive tutorial.
