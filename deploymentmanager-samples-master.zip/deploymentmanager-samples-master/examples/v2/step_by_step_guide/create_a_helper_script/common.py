"""Generates name of a VM."""


def GenerateMachineName(prefix, suffix):
  return prefix + "-" + suffix

