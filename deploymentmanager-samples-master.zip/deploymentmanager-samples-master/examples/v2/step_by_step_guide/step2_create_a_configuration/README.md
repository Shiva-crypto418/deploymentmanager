# Create a configuration with two virtual machine instances

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/create-a-configuration)
configuration file that deploys two virtual machine instances with different
machine type. To use it, replace [MY_PROJECT] with your project ID.
