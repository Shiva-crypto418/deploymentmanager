# Create a configuration using metadata and startup scripts

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/setting-metadata-and-startup-scripts)
configuration file which creates two virtual machine instances using multiple
Jinja or Python templates with startup-scripts.
