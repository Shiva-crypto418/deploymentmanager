# Create a configuration using references

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/step-by-step-guide/using-references)
configuration file which creates a network and two virtual machine instances.
The virtual machine instance has a reference to the network resource. To use it,
replace [MY_PROJECT] with your project ID.
