Template to deploy an autoscaled instance group with a container image for each
instance.

