# Creates a VM with user specified disks attached to it.

## Overview

This example creates a VM with user specified disks attached to it. The template
uses a for loop to create and attach those disks.
