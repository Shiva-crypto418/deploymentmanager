# Create a configuration declaring outputs

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/docs/configuration/expose-information-outputs#deciding_to_declare_an_output_in_a_configuration_or_a_template)
configuration example that declares outputs in template and configuration files.
