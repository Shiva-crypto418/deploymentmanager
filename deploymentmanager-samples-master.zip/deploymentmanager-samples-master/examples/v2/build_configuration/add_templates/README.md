# Create a configuration with templates

## Overview

This is [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/docs/configuration/templates/create-basic-template)
configuration example that uses a basic template, as well as a template with
template variables and environment variables. The template files are created in
both Jinja and Python.
