# Create a configuration with explicit dependency

## Overview

This is a [Google Cloud Deployment Manager](https://cloud.google.com/deployment-manager/docs/configuration/create-explicit-dependencies)
configuration file that creates two virtual machine instances, where
frontend-instance is dependent on the creation of backend-instance.
