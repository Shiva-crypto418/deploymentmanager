# Custom Machine Type Sample

This is an example of specifying the machine type to create a VM with 4 CPUs and 5GB (5120 MB) of memory.

See:
https://cloud.google.com/compute/docs/instances/creating-instance-with-custom-machine-type
